function toggleMenu(){
    var menu = document.getElementById("mobile-nav-links");
    if(menu.style.display === "block"){
        menu.style.display = "none";
        console.log("menu is hidden");
    }
    else{
        menu.style.display = "block";
        menu.style.visibility = "visible";
        console.log("menu is visible");
    }
}

//-- Filter events on schedule page
function changeDay(value){
    //-- Show all events
    if(value == "0"){
        var schedule = document.getElementsByClassName("schedule");
        var i;
        for(i = 0; i < schedule.length; i++){
            schedule[i].style.display = "block";
        }
        return;
    }
    //-- Show events for selected day
    else{
        var schedule = document.getElementsByClassName("schedule");
        var i;
        for(i = 0; i < schedule.length; i++){
            schedule[i].style.display = "none";
        }
        document.getElementById('schedule-'+value).style.display = "block";
    }
}