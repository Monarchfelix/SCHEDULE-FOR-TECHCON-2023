// register.js

document.addEventListener('DOMContentLoaded', function () {
    const registrationForm = document.getElementById('registrationForm');

    registrationForm.addEventListener('submit', function (event) {
        let valid = true;

        // Validate prefix
        const prefix = document.getElementById('prefix');
        if (!prefix.value.trim()) {
            alert('Please select a prefix.');
            valid = false;
        }

        // Validate first name
        const firstName = document.getElementById('firstName');
        if (!isAlpha(firstName.value.trim())) {
            alert('First name should only contain characters.');
            valid = false;
        }

        // Validate last name
        const lastName = document.getElementById('lastName');
        if (!isAlpha(lastName.value.trim())) {
            alert('Last name should only contain characters.');
            valid = false;
        }

        // Validate gender
        const gender = document.getElementById('gender');
        if (!gender.value.trim()) {
            alert('Please select your gender.');
            valid = false;
        }

        // Validate age
        const age = document.getElementById('Age');
        if (!age.value.trim()) {
            alert('Please enter your age.');
            valid = false;
        }

        // Validate phone
        const phone = document.getElementById('phone');
        if (!isNumeric(phone.value.trim())) {
            alert('Phone number should only contain digits.');
            valid = false;
        }

        // Validate email
        const email = document.getElementById('email');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email.value.trim())) {
            alert('Please enter a valid email address.');
            valid = false;
        }

        // Validate other fields as needed

        if (!valid) {
            event.preventDefault(); // Prevent form submission if validation fails
        }
    });

    // Utility function to check if a string contains only alphabetical characters
    function isAlpha(value) {
        return /^[A-Za-z]+$/.test(value);
    }

    // Utility function to check if a string contains only numeric characters
    function isNumeric(value) {
        return /^\d+$/.test(value);
    }
});
