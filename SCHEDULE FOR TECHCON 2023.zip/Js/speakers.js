document.addEventListener('DOMContentLoaded', function () {
    const speakers = document.querySelectorAll('.speaker');

    speakers.forEach(function (speaker) {
        const link = speaker.getAttribute('data-link');

        speaker.addEventListener('click', function (event) {
            // Open the link in a new tab
            window.open(link, '_blank');

            // Prevent the default behavior (following the href)
            event.preventDefault();
        });
    });
});
